# Taycan Premium Concept

Projeto estático de portfólio, não oficial, inspirado no Porsche Taycan e usando imagens oficiais hospedadas pela Porsche.

## Deploy
- `index.html` está na raiz.
- Não exige build.
- Pode ser enviado diretamente para o Netlify.
- As imagens são carregadas de domínios oficiais Porsche/CDN e exigem conexão com a internet.
